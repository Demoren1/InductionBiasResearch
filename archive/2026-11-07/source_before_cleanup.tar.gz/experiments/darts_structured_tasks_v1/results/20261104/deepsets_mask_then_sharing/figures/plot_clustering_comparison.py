"""Plot saved DeepSets states before and after clustering, without fitting."""

import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import BoundaryNorm, ListedColormap


def main():
    destination = Path(__file__).resolve().parent
    output = destination.parent
    parent = output.parent / "deepsets_refinement"
    selection = json.loads((output / "selection.json").read_text())
    specification = json.loads((output / "specification.json").read_text())
    with np.load(output / "selected_states.npz") as archive:
        after = dict(archive)
    with np.load(parent / "selected_states.npz") as archive:
        direct = dict(archive)
    with np.load(parent / "teacher_audit_only.npz") as archive:
        truth = dict(archive)
    with np.load(output / "masked_numeric.npz") as archive:
        row = selection["row"]
        restart = int(archive["query_mse"][row].argmin())
        independent = archive["weights"][row, restart].copy()
        independent_numeric = archive["numeric"][row, restart].copy()

    codes = specification["codes"]
    indices = after["indices"]
    mask = indices != 0
    centers = np.array(
        [np.abs(independent[np.abs(indices) == group]).mean()
         for group in range(1, codes + 1)]
    )
    quantized = np.r_[0.0, centers][np.abs(indices)] * np.sign(indices)
    columns = after["aligned_columns"]
    row_order = truth["permutation"]
    before_weights = independent[:, columns][row_order]
    clustered_weights = quantized[:, columns][row_order]
    final_weights = after["learned_inherited_weights"][:, columns][row_order]
    direct_index = direct["aligned_indices"][row_order]
    final_index = after["aligned_indices"][row_order]
    true_index = after["true_indices"][row_order]

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.titlesize": 12,
            "figure.dpi": 140,
            "savefig.dpi": 180,
        }
    )
    categorical_colors = [
        "#4974a5", "#a68bc0", "#dd9358", "#71ad8d", "#f4f4f4",
        "#1b9e77", "#d95f02", "#7570b3", "#1f78b4",
    ]
    cmap = ListedColormap(categorical_colors)
    norm = BoundaryNorm(np.arange(-codes - 0.5, codes + 1), cmap.N)
    fig, axes = plt.subplots(1, 3, figsize=(15, 5.1), constrained_layout=True)
    panels = (
        (direct_index, "До: прямой DARTS\n2 группы; 17 ошибок из 256"),
        (final_index, "После свободных весов и кластеризации\n4 группы; 0 ошибок из 256"),
        (true_index, "Истинный индексатор\n4 группы"),
    )
    for axis, (matrix, title) in zip(axes, panels):
        image = axis.imshow(matrix, cmap=cmap, norm=norm, interpolation="nearest")
        axis.set_title(title, pad=12)
        axis.set_xlabel("Скрытый нейрон")
        axis.set_ylabel("Координата входа")
        axis.set_xticks(range(0, 16, 2))
        axis.set_yticks(range(0, 16, 2))
        axis.set_xticks(np.arange(-0.5, 16, 1), minor=True)
        axis.set_yticks(np.arange(-0.5, 16, 1), minor=True)
        axis.grid(which="minor", color="white", linewidth=0.5)
        axis.tick_params(which="minor", bottom=False, left=False)
        for coordinate, neuron in zip(*np.nonzero(matrix)):
            axis.text(
                neuron, coordinate, str(int(matrix[coordinate, neuron])),
                ha="center", va="center", fontsize=8, color="white",
                fontweight="bold",
            )
    colorbar = fig.colorbar(image, ax=axes, ticks=range(-codes, codes + 1), shrink=0.8)
    colorbar.set_label("Метка группы; 0 = отключено, −k = значение −Cₖ")
    fig.suptitle("DeepSets: найденные группы при неизменной бинарной маске", fontsize=15)
    for extension in ("png", "svg"):
        fig.savefig(
            destination / f"indexators_before_after.{extension}",
            bbox_inches="tight",
        )
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(16.5, 5.3), constrained_layout=True)
    maximum = max(float(np.abs(matrix).max()) for matrix in (
        before_weights, clustered_weights, final_weights
    ))
    maximum = np.ceil(maximum * 10) / 10
    panels = (
        (before_weights, "До кластеризации\n32 независимых веса"),
        (clustered_weights, "Сразу после кластеризации\n4 центра; кодбук ещё не дообучен"),
        (final_weights, "После дообучения кодбука\n4 значения и их знаковые двойники"),
    )
    for axis, (matrix, title) in zip(axes, panels):
        image = axis.imshow(
            matrix, cmap="RdBu_r", vmin=-maximum, vmax=maximum,
            interpolation="nearest",
        )
        axis.set_title(title, pad=12)
        axis.set_xlabel("Скрытый нейрон")
        axis.set_ylabel("Координата входа")
        axis.set_xticks(range(0, 16, 2))
        axis.set_yticks(range(0, 16, 2))
        axis.set_xticks(np.arange(-0.5, 16, 1), minor=True)
        axis.set_yticks(np.arange(-0.5, 16, 1), minor=True)
        axis.grid(which="minor", color="#dddddd", linewidth=0.35)
        axis.tick_params(which="minor", bottom=False, left=False)
        for coordinate, neuron in zip(*np.nonzero(matrix)):
            value = matrix[coordinate, neuron]
            axis.text(
                neuron, coordinate, f"{value:.2f}", ha="center", va="center",
                fontsize=6.6,
                color="white" if abs(value) > 0.55 * maximum else "#222222",
            )
    colorbar = fig.colorbar(image, ax=axes, shrink=0.8)
    colorbar.set_label("Численное значение веса; единая шкала")
    fig.suptitle("DeepSets: веса из сохранённого запуска до и после кластеризации", fontsize=15)
    for extension in ("png", "svg"):
        fig.savefig(
            destination / f"weights_before_after.{extension}",
            bbox_inches="tight",
        )
    plt.close(fig)

    groups = []
    for group in range(1, codes + 1):
        active = np.abs(indices) == group
        values = np.abs(independent[active])
        groups.append(
            {
                "raw_group": group,
                "edges": int(active.sum()),
                "minimum_before": float(values.min()),
                "maximum_before": float(values.max()),
                "center_before_refit": float(centers[group - 1]),
                "code_after_refit": float(after["learned_inherited_numeric"][group - 1]),
            }
        )
    source_paths = (
        output / "selection.json", output / "selected_states.npz",
        output / "masked_numeric.npz", parent / "selected_states.npz",
        parent / "teacher_audit_only.npz",
    )
    details = {
        "source_row": row,
        "query_selected_restart": restart,
        "before_values_are_actual_independent_weights": True,
        "clustering_centers_reconstructed_from_saved_assignments": True,
        "mask_changes": int(np.count_nonzero((direct["indices"] != 0) != mask)),
        "categorical_errors_before": int(np.count_nonzero(direct_index != true_index)),
        "categorical_errors_after": int(np.count_nonzero(final_index != true_index)),
        "display_only_alignment": "Teacher input order, matched hidden columns and group names. No teacher information was used to fit or cluster.",
        "groups_in_raw_learned_label_order": groups,
        "source_sha256": {
            str(path.relative_to(output.parent)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in source_paths
        },
    }
    (destination / "clustering_comparison.json").write_text(
        json.dumps(details, indent=2, ensure_ascii=False) + "\n"
    )
    np.savez_compressed(
        destination / "clustering_comparison.npz",
        before_independent_weights=independent,
        before_numeric=independent_numeric,
        immediately_clustered_weights=quantized,
        final_weights=after["learned_inherited_weights"],
        final_numeric=after["learned_inherited_numeric"],
        raw_cluster_indices=indices,
        display_before_weights=before_weights,
        display_clustered_weights=clustered_weights,
        display_final_weights=final_weights,
        display_direct_index=direct_index,
        display_cluster_index=final_index,
        display_true_index=true_index,
        row_order=row_order,
        columns=columns,
    )
    print(json.dumps(details, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
