"""Freeze the decoder, select z on source tasks, then evaluate sealed masks."""

import argparse
import json
from pathlib import Path

import torch

from pattern.bank.imp import QueryCheckpoint
from pattern.io import ROOT, device_name, new_directory

from .common import (
    DEFAULT_CONFIG,
    HIDDEN,
    ROWS,
    K,
    Model,
    bce,
    digest,
    fit,
    initial,
    load_bank,
    logits,
    progress,
    references,
    save_history,
    save_json,
    save_maps,
    save_torch,
    target,
    tasks,
    topk,
)


def repeated_initial(task_ids, candidates, replicas, seed, device, mlp=None):
    seeds = [
        seed + 1009 * (int(task[2:], 2) + 16 * (task[0] == "B")) + replica * 13
        for replica in range(replicas)
        for task in task_ids
    ]
    template = initial(seeds, device, mlp)
    return {
        key: value.repeat(candidates, *([1] * (value.ndim - 1)))
        for key, value in template.items()
    }


def observations(data, task_ids, device):
    x = {
        key: value.to(device) for key, value in data.items() if key != "probe"
    }
    return x, {
        key: torch.stack([target(value, task) for task in task_ids])
        for key, value in x.items()
    }


def relaxed_topk(scores, temperature):
    """Successive softmax selection (Xie & Ermon, IJCAI 2019, Eq. 5)."""
    logits = scores.flatten(-2)
    relaxed = torch.zeros_like(logits)
    for _ in range(K):
        selection = (logits / temperature).softmax(-1)
        relaxed = relaxed + selection
        logits = logits + (1 - selection).clamp_min(1e-7).log()
    return relaxed.reshape_as(scores)


def gumbel_topk(scores, temperature, noise_scale, generator):
    """Exactly K edges forward; RelaxedTopK gradients backward."""
    uniform = torch.rand(
        scores.shape, device=scores.device, generator=generator
    ).clamp(1e-7, 1 - 1e-7)
    perturbed = scores - noise_scale * (-uniform.log()).log()
    relaxed = relaxed_topk(perturbed, temperature)
    return topk(perturbed) + (relaxed - relaxed.detach())


def source_bce(masks, template, x, y, options, mlp, differentiable=False):
    """Fit fresh source MLPs; each candidate uses the same seeded weights."""
    count = len(masks)
    masks = masks.repeat_interleave(len(y["support"]), 0)
    state = {
        key: value.repeat(count, *([1] * (value.ndim - 1))).requires_grad_()
        for key, value in template.items()
    }
    ys, yq = (y[key].repeat(count, 1) for key in ("support", "query"))
    for step in range(1, options["inner_steps"] + 1):
        slope = (
            mlp.get("warmup_slope", 0.0)
            if step <= mlp.get("warmup_steps", 0)
            else 0.0
        )
        gradients = torch.autograd.grad(
            bce(state, masks, x["support"], ys, slope).sum(),
            tuple(state.values()),
            create_graph=differentiable,
        )
        state = {
            key: value - options["inner_lr"] * gradient
            for (key, value), gradient in zip(state.items(), gradients)
        }
        if not differentiable:
            state = {
                key: value.detach().requires_grad_()
                for key, value in state.items()
            }
    loss = bce(state, masks, x["query"], yq).reshape(count, -1).mean(1)
    if not torch.isfinite(loss).all():
        raise RuntimeError("nonfinite source objective")
    return loss


def search(
    decoder, task_ids, data, config, options, destination, device, enabled
):
    x, y = observations(
        {key: data[key] for key in ("support", "query")}, task_ids, device
    )
    seed = config["seed"] + (task_ids[0][0] == "B")
    generator = torch.Generator().manual_seed(seed + 9001)
    method = options.get("z_method", "gumbel")
    z = torch.randn(
        options["z_starts"], config["model"]["latent_dim"], generator=generator
    ).to(device)
    z.requires_grad_(method != "evolution")
    with torch.no_grad():
        initial_scores = decoder(z).cpu()
    optimizer = torch.optim.Adam([z], lr=options["z_lr"])
    noise_generator = torch.Generator(device=device).manual_seed(
        seed + (9201 if method == "gumbel" else 9101)
    )
    checkpoint = QueryCheckpoint({"z": z}, (len(z),))
    template = repeated_initial(
        task_ids, 1, 1, config["seed"] + 310007, device, config["bank"]
    )
    cache = {}

    def score(latent):
        # The hard-mask objective is constant within a top-32 region.
        with torch.no_grad():
            masks = topk(decoder(latent))
        keys = [mask.numpy().tobytes() for mask in masks.to(torch.uint8).cpu()]
        missing = {}
        for index, key in enumerate(keys):
            if key not in cache:
                missing.setdefault(key, index)
        if missing:
            values = (
                source_bce(
                    masks[list(missing.values())],
                    template,
                    x,
                    y,
                    options,
                    config["bank"],
                )
                .detach()
                .cpu()
                .tolist()
            )
            cache.update(zip(missing, values))
        return z.new_tensor([cache[key] for key in keys])

    history = []
    accepted = 0
    gradient_observed = False
    loop = progress(
        range(options["z_steps"] + 1),
        enabled,
        desc=f"Search z / {task_ids[0][0]}",
        unit="step",
    )
    for step in loop:
        if method == "gradient":
            optimizer.zero_grad(set_to_none=True)
            loss = source_bce(
                topk(decoder(z), True),
                template,
                x,
                y,
                options,
                config["bank"],
                differentiable=True,
            )
        elif method == "gumbel" or step == 0:
            loss = score(z.detach())
        if method == "gumbel" and step < options["z_steps"]:
            fraction = step / max(1, options["z_steps"] - 1)
            temperature, noise_scale = (
                options[key]
                * (options[key + "_end"] / options[key]) ** fraction
                for key in ("gumbel_tau", "gumbel_noise")
            )
            samples = options["gumbel_samples"]
            masks = gumbel_topk(
                decoder(z).repeat(samples, 1, 1),
                temperature,
                noise_scale,
                noise_generator,
            )
            optimizer.zero_grad(set_to_none=True)
            sampled_loss = (
                source_bce(
                    masks,
                    template,
                    x,
                    y,
                    options,
                    config["bank"],
                    differentiable=True,
                )
                .reshape(samples, len(z))
                .mean(0)
            )
        checkpoint.update({"z": z}, loss.detach(), step)
        history.append(
            {
                "step": step,
                "source_query_bce": float(loss.detach().mean()),
                "best_restart_bce": float(loss.detach().min()),
                "restart_bce": loss.detach().cpu().tolist(),
                "accepted_restarts": accepted,
                "evaluated_masks": len(cache),
            }
        )
        save_json(destination / "search/history.json", history)
        loop.set_postfix(bce=f"{history[-1]['source_query_bce']:.5f}")
        if step == options["z_steps"]:
            continue
        if method != "evolution":
            objective = sampled_loss if method == "gumbel" else loss
            history[-1]["optimization_bce"] = float(objective.detach().mean())
            if method == "gumbel":
                history[-1].update(
                    temperature=temperature, gumbel_noise_scale=noise_scale
                )
            objective.sum().backward()
            if z.grad is None or not torch.isfinite(z.grad).all():
                raise RuntimeError("invalid z gradient")
            history[-1]["z_gradient_norm"] = float(z.grad.detach().norm())
            gradient_observed |= history[-1]["z_gradient_norm"] > 0
            torch.nn.utils.clip_grad_norm_([z], 5.0, error_if_nonfinite=True)
            if method == "gumbel":
                previous = z.detach().clone()
                moments = {
                    key: value.clone()
                    for key, value in optimizer.state[z].items()
                    if key != "step"
                }
            optimizer.step()
            if method == "gradient":
                continue
            # Search along the Adam direction, using actual hard-mask BCE.
            scales = z.new_tensor([1.0, 0.5, 2.0])[:, None, None]
            proposals = previous + scales * (z.detach() - previous)
        else:
            noise = torch.randn(
                options["z_candidates"] // 2,
                *z.shape,
                device=device,
                generator=noise_generator,
            )
            proposals = z[None] + options["z_radius"] * torch.cat(
                (noise, -noise)
            )
        risks = score(proposals.flatten(0, 1)).reshape(-1, len(z))
        best, indices = risks.min(0)
        keep = best <= loss if method == "gumbel" else best < loss
        winners = proposals[indices, torch.arange(len(z), device=device)]
        if method == "gumbel":
            with torch.no_grad():
                z.copy_(torch.where(keep[:, None], winners, previous))
                for key, value in optimizer.state[z].items():
                    if key != "step":
                        value.copy_(
                            torch.where(
                                keep[:, None],
                                value,
                                moments.get(key, torch.zeros_like(value)),
                            )
                        )
        else:
            z = torch.where(keep[:, None], winners, z)
            loss = torch.where(keep, best, loss)
        accepted = int(keep.sum())
    if method != "evolution" and not gradient_observed:
        raise RuntimeError("source BCE did not produce a z gradient")
    save_history(destination / "search", history, "step")
    with torch.no_grad():
        scores = decoder(checkpoint.state["z"]).cpu()
    return (
        scores,
        initial_scores,
        checkpoint.state["z"].cpu(),
        checkpoint.steps.cpu(),
    )


def fresh(
    masks,
    task_ids,
    data,
    options,
    seed,
    device,
    enabled,
    final=False,
    mlp=None,
):
    """Match fresh seeds across methods, independently for each task."""
    # The caller seals candidate masks before passing held-out tasks.
    needed = ("support", "query", "test" if final else "validation")
    x, y = observations({key: data[key] for key in needed}, task_ids, device)
    count = len(masks)
    replicas = options["replicas"]
    shape = (count, replicas, len(task_ids))
    expanded = (
        masks.to(device)[:, None, None]
        .expand(*shape, ROWS, HIDDEN)
        .reshape(-1, ROWS, HIDDEN)
    )
    ys, yq = (
        y[key].repeat(count * replicas, 1) for key in ("support", "query")
    )
    original = repeated_initial(task_ids, count, replicas, seed, device, mlp)
    state, steps, history = fit(
        original,
        expanded,
        (x["support"], ys),
        (x["query"], yq),
        options["child_steps"],
        options["child_lr"],
        select_every=options["select_every"],
        enabled=enabled,
        log_every=options["log_every"],
        mlp=mlp,
    )
    split = "test" if final else "validation"
    expected = y[split].repeat(count * replicas, 1)
    with torch.no_grad():
        output = logits(state, expanded, x[split])
        risk = bce(state, expanded, x[split], expected).reshape(shape).cpu()
        oracle = (
            torch.nn.functional.binary_cross_entropy(
                expected, expected, reduction="none"
            )
            .mean(-1)
            .reshape(shape)
            .cpu()
        )
        accuracy = (
            ((output > 0) == (expected > 0.5))
            .float()
            .mean(-1)
            .reshape(shape)
            .cpu()
        )
    return {
        "bce": risk,
        "excess_bce": risk - oracle,
        "accuracy": accuracy,
        "selected_steps": steps.reshape(shape),
        "oracle_bce": oracle,
        "history": history,
    }


def frequency(cards, family=None):
    return topk(
        torch.cat(
            [
                card["masks"][card["split"] == 0]
                for task, card in cards.items()
                if family is None or task[0] == family
            ]
        ).mean(0, keepdim=True)
    )[0]


def evaluate(run, evaluation_id, device, enabled, overrides):
    checkpoint = torch.load(
        run / "checkpoints/best.pt", weights_only=True, map_location="cpu"
    )
    config = checkpoint["config"]
    reference = checkpoint["bank"]
    if (
        digest(Path(reference["path"]) / "manifest.json")
        != reference["sha256"]
    ):
        raise ValueError("training bank changed")
    _, _, cards, data = load_bank(reference["path"], config)
    defaults = json.loads(DEFAULT_CONFIG.read_text())["evaluation"]
    options = {
        **defaults,
        **config["evaluation"],
        **{
            key: value
            for key, value in defaults.items()
            if key.startswith("gumbel_")
            or key in ("z_method", "z_lr", "z_steps")
        },
        **{
            key: value for key, value in overrides.items() if value is not None
        },
    }
    if options["z_method"] not in ("gumbel", "evolution", "gradient"):
        raise ValueError("z_method must be gumbel, evolution or gradient")
    for key, value in options.items():
        if key != "z_method" and value <= 0:
            raise ValueError(f"evaluation {key} must be positive")
    if any(
        options[key + "_end"] > options[key]
        for key in ("gumbel_tau", "gumbel_noise")
    ):
        raise ValueError("Gumbel temperature and noise must not increase")
    if options["z_candidates"] < 2 or options["z_candidates"] % 2:
        raise ValueError("z_candidates must be positive and even")
    if config["bank"].get("warmup_steps", 0) >= min(
        options["inner_steps"], options["child_steps"]
    ):
        raise ValueError("inner_steps and child_steps must exceed MLP warmup")
    model = Model(tasks(config), config["model"]).to(device)
    model.load_state_dict(checkpoint["model"])
    decoder = model.decoder.eval().requires_grad_(False)
    frozen = {
        key: value.detach().cpu().clone()
        for key, value in decoder.state_dict().items()
    }
    destination = new_directory(run / "evaluations", evaluation_id)
    report = {
        "checkpoint_epoch": checkpoint["epoch"],
        "search_method": options["z_method"],
        "families": {},
    }
    save_json(
        destination / "protocol.json",
        {
            "config": config,
            "options": options,
            "bank": reference,
            "outer_trainable": "z only",
            "outer_loss": "source-query soft-target BCE after fresh SGD",
            "search_method": options["z_method"],
            "proposal_selection": (
                "strict source-query improvement per restart"
                if options["z_method"] == "evolution"
                else (
                    "Adam gradient direction, scales 1/0.5/2; accept "
                    "nonincreasing deterministic source-query BCE"
                    if options["z_method"] == "gumbel"
                    else "Adam; best deterministic source-query checkpoint"
                )
            ),
            "selection": "source validation BCE; held-out tasks excluded",
            "accuracy_target": "p > 0.5",
            "reference_set": "four Bayes-optimal masks, modulo hidden columns",
        },
    )
    for family in "AB":
        output = destination / family
        output.mkdir()
        source = tasks(config, family=family)
        heldout = tasks(config, "test", family)
        scores, initial_scores, z, steps = search(
            decoder, source, data, config, options, output, device, enabled
        )
        masks = topk(scores)
        selection = fresh(
            torch.cat((masks, topk(initial_scores))),
            source,
            data,
            options,
            config["seed"] + 710009,
            device,
            enabled,
            mlp=config["bank"],
        )
        risks = selection["bce"].mean((1, 2))
        selected = int(risks[: len(masks)].argmin())
        best_random = int(risks[len(masks) :].argmin())
        save_history(output / "selection", selection.pop("history"), "step")
        save_torch(
            output / "selection.pt",
            {
                **selection,
                "source_tasks": source,
                "z": z,
                "search_steps": steps,
                "selected_index": selected,
                "best_random_index": best_random,
                "candidate_order": "optimized restarts, then initial restarts",
            },
        )
        artifacts = save_maps(
            output, "latent_search", scores, source[0], selected
        )
        initial_artifacts = save_maps(
            output, "initial_z", initial_scores, source[0]
        )
        candidate_masks = torch.cat(
            (
                masks[selected : selected + 1],
                topk(initial_scores),
                torch.stack(
                    (
                        frequency(cards),
                        frequency(cards, family),
                        references("A_0000")[0],
                        references("B_0000")[0],
                    )
                ),
                references(source[0]),
            )
        )
        names = [
            "optimized_z",
            *[f"random_z_{index}" for index in range(len(initial_scores))],
            "global_frequency",
            "family_frequency",
            "fixed_A",
            "fixed_B",
            *[f"oracle_{index}" for index in range(4)],
        ]
        save_torch(
            output / "sealed_masks.pt",
            {
                "masks": candidate_masks,
                "methods": names,
                "z": z[selected],
                "selected_logits": scores[selected],
                "probabilities": scores[selected].sigmoid(),
                "source_validation_bce": float(risks[selected]),
            },
        )
        # First held-out target call, after masks and z are fixed on disk.
        result = fresh(
            candidate_masks,
            heldout,
            data,
            options,
            config["seed"] + 910019,
            device,
            enabled,
            final=True,
            mlp=config["bank"],
        )
        save_history(output / "test", result.pop("history"), "step")
        save_torch(
            output / "test/values.pt",
            {**result, "tasks": heldout, "methods": names},
        )
        records = {
            name: {
                key: float(result[key][index].mean())
                for key in ("bce", "excess_bce", "accuracy")
            }
            for index, name in enumerate(names)
        }
        records["random_z_mean"] = {
            key: sum(
                records[f"random_z_{index}"][key]
                for index in range(len(initial_scores))
            )
            / len(initial_scores)
            for key in ("bce", "excess_bce", "accuracy")
        }
        records["best_random_z"] = records[f"random_z_{best_random}"]
        iou = artifacts["iou"]
        exact = iou == 1
        counts = torch.bincount(artifacts["variants"][exact], minlength=4)
        report["families"][family] = {
            "source_tasks": source,
            "heldout_tasks": heldout,
            "selected_index": selected,
            "selected_search_step": int(steps[selected]),
            "selected_mask_changed": not torch.equal(
                artifacts["canonical"][selected],
                initial_artifacts["canonical"][selected],
            ),
            "selected_iou": float(iou[selected]),
            "initial_mean_iou": float(initial_artifacts["iou"].mean()),
            "optimized_mean_iou": float(iou.mean()),
            "exact_fraction": float(exact.float().mean()),
            "exact_variant_counts": counts.tolist(),
            "covered_variants": int((counts > 0).sum()),
            "source_validation_bce": risks[: len(masks)].tolist(),
            "initial_source_validation_bce": risks[len(masks) :].tolist(),
            "best_random_index": best_random,
            "methods": records,
        }
        print(
            f"{family}: selected IoU={iou[selected]:.4f}; "
            f"held-out BCE={records['optimized_z']['bce']:.5f}; "
            f"excess={records['optimized_z']['excess_bce']:.5f}",
            flush=True,
        )
    if any(
        not torch.equal(value.cpu(), frozen[key])
        for key, value in decoder.state_dict().items()
    ):
        raise RuntimeError("frozen decoder changed")
    report.update(
        decoder_frozen=True,
        z_gradient_observed=options["z_method"] != "evolution",
        k=K,
    )
    save_json(destination / "metrics.json", report)
    save_json(
        destination / "COMPLETE.json",
        {"families": ["A", "B"], "decoder_frozen": True},
    )
    return destination


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run", type=Path, default=ROOT / "multimask/runs/nf_vae_v3"
    )
    parser.add_argument("--evaluation-id")
    parser.add_argument(
        "--z-method", choices=("gumbel", "evolution", "gradient")
    )
    parser.add_argument("--device", default="mps")
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--no-progress", action="store_true")
    integers = (
        "z-starts",
        "z-candidates",
        "gumbel-samples",
        "z-steps",
        "inner-steps",
        "child-steps",
        "select-every",
        "replicas",
        "log-every",
    )
    floats = (
        "z-lr",
        "z-radius",
        "inner-lr",
        "child-lr",
        "gumbel-tau",
        "gumbel-tau-end",
        "gumbel-noise",
        "gumbel-noise-end",
    )
    for flag in integers:
        parser.add_argument("--" + flag, type=int)
    for flag in floats:
        parser.add_argument("--" + flag, type=float)
    args = parser.parse_args()
    if args.threads < 1:
        raise ValueError("threads must be positive")
    torch.set_num_threads(args.threads)
    device = device_name(args.device)
    overrides = {
        flag.replace("-", "_"): getattr(args, flag.replace("-", "_"))
        for flag in (*integers, *floats, "z-method")
    }
    print(f"Device: {device}", flush=True)
    destination = evaluate(
        args.run, args.evaluation_id, device, not args.no_progress, overrides
    )
    print(f"Evaluation saved: {destination}", flush=True)


if __name__ == "__main__":
    main()
