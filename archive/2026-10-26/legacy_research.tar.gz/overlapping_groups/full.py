"""Run a frozen 144-combination experiment with packed CUDA batches."""

import argparse
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch

from .io import (
    PACKAGE,
    REPOSITORY,
    checked_load,
    load_manifest,
    save_json,
    sha256,
    snapshot,
    source_hashes,
    validate_config,
)
from .masks import canonical_mask
from .problem import families, reference
from .runtime import cuda_devices


def run_stage(name, module, arguments, root):
    """Append stage logs; failures leave existing artifacts available to resume."""
    logs = root / "logs"
    logs.mkdir(exist_ok=True)
    command = [sys.executable, "-u", "-m", module, *map(str, arguments)]
    environment = {
        **os.environ,
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
        "MPLCONFIGDIR": "/tmp/overlapping-full-plots",
    }
    started = time.monotonic()
    print(json.dumps({"stage": name, "status": "running"}), flush=True)
    with (logs / f"{name}.log").open("a", buffering=1) as log:
        process = subprocess.run(
            command,
            cwd=REPOSITORY,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )
    if process.returncode:
        raise RuntimeError(
            f"Stage {name} failed; inspect {logs / (name + '.log')}"
        )
    result = {
        "stage": name,
        "status": "complete",
        "elapsed_seconds": time.monotonic() - started,
    }
    print(json.dumps(result), flush=True)
    return result


def audit_bank(bank, destination):
    """Reject exact held-out masks anywhere in source cards before VAE fitting."""
    manifest = load_manifest(bank)
    bank_hash = sha256(bank / "manifest.json")
    if destination.exists():
        previous = json.loads(destination.read_text())
        if previous["bank_sha256"] != bank_hash:
            raise ValueError("Novelty audit belongs to another bank")
        return previous
    codes, counts = set(), {}
    for task in manifest["completed_tasks"].values():
        if task["split"] != "train":
            raise ValueError(
                "The full experiment collects only training combinations"
            )
        card = checked_load(
            bank / task["path"] / "cards.pt", task["hashes"]["cards.pt"]
        )
        masks = (
            canonical_mask(card["targets"].float()).bool().flatten(1).numpy()
        )
        codes.update(row.tobytes() for row in np.packbits(masks, axis=1))
        for role in card["network_roles"]:
            counts[role] = counts.get(role, 0) + 1
    held_out = []
    for family in manifest["family_definitions"]:
        if family["split"] == "train":
            continue
        target = canonical_mask(reference(family, "cpu")[None]).bool().numpy()
        present = np.packbits(target.reshape(-1)).tobytes() in codes
        held_out.append(
            {
                "family": family["id"],
                "split": family["split"],
                "present_in_source_cards": present,
            }
        )
    if any(row["present_in_source_cards"] for row in held_out):
        raise ValueError(
            "A held-out mask accidentally occurs in source IMP cards; see source bank before proceeding"
        )
    result = {
        "bank_sha256": bank_hash,
        "role_counts": counts,
        "distinct_imp_masks": len(codes),
        "held_out": held_out,
    }
    save_json(destination, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--devices", default="cuda:0,cuda:1,cuda:2,cuda:3")
    parser.add_argument(
        "--runs", type=Path, default=PACKAGE / "runs/composition_full_v1"
    )
    parser.add_argument(
        "--bank",
        type=Path,
        default=REPOSITORY
        / "data/overlapping_groups/banks/composition_full_v1",
    )
    parser.add_argument(
        "--seeds", type=int, nargs="+", default=[4213, 4214, 4215, 4216]
    )
    parser.add_argument("--train-count", type=int, default=128)
    parser.add_argument("--models-per-gpu", type=int)
    parser.add_argument("--bank-memory-gib", type=float, default=30)
    parser.add_argument("--vae-memory-gib", type=float, default=30)
    parser.add_argument("--workers-per-device", type=int, default=12)
    parser.add_argument("--search-memory-gib", type=float, default=4)
    parser.add_argument(
        "--plan-only",
        action="store_true",
        help="Print the plan without creating artifacts or accessing CUDA",
    )
    args = parser.parse_args()
    torch.set_num_threads(1)
    devices = cuda_devices(args.devices)
    if (
        args.train_count < 3
        or args.workers_per_device < 1
        or len(set(args.seeds)) != len(args.seeds)
    ):
        parser.error(
            "Use at least three source networks, positive workers, and distinct seeds"
        )
    if (
        min(args.bank_memory_gib, args.vae_memory_gib, args.search_memory_gib)
        <= 2
    ):
        parser.error(
            "Each per-process memory budget must exceed the 2 GiB reserve"
        )
    args.runs, args.bank = args.runs.resolve(), args.bank.resolve()
    configs = PACKAGE / "configs"
    bank_config = json.loads(
        (configs / "composition_full_bank.json").read_text()
    )
    vae_config = json.loads(
        (configs / "composition_full_vae.json").read_text()
    )
    search_config = json.loads(
        (configs / "composition_full_transfer.json").read_text()
    )
    definitions, structure = families(bank_config)
    source_tasks = (
        bank_config["families"]["train"] * bank_config["functions_per_family"]
    )
    packed = (
        args.models_per_gpu
        or math.ceil(source_tasks / len(devices)) * args.train_count
    )
    if packed < args.train_count:
        parser.error("The packed batch must hold at least one complete task")
    holdout = max(1, args.train_count // 8)
    vae_config["training"].update(
        {
            "batch_per_task": args.train_count - 2 * holdout,
            "epochs": 600,
            "warmup_epochs": 90,
            "patience": 120,
        }
    )
    split_configs = {
        split: {**search_config, "target_split": split}
        for split in ("validation", "test")
    }
    for config in split_configs.values():
        validate_config(config)
    plan = {
        "devices": devices,
        "source_tasks": source_tasks,
        "source_networks": source_tasks * args.train_count,
        "source_networks_per_function": args.train_count,
        "packed_mlp_slots_per_gpu": packed,
        "bank_memory_gib": args.bank_memory_gib,
        "vae_batch_per_function": vae_config["training"]["batch_per_task"],
        "vae_cards_per_update": source_tasks
        * vae_config["training"]["batch_per_task"],
        "vae_memory_gib": args.vae_memory_gib,
        "decoder_seeds": args.seeds,
        "search_workers_per_gpu": args.workers_per_device,
        "search_allocator_limit_gib_per_worker": args.search_memory_gib - 2,
        "candidate_fits_per_search": search_config["search"]["starts"]
        * (
            1
            + search_config["search"]["steps"]
            * (
                search_config["search"]["gumbel_samples"]
                + len(search_config["search"]["proposal_scales"])
            )
        ),
        "searches": {
            split: bank_config["families"][split] * len(args.seeds)
            for split in split_configs
        },
        "bank": str(args.bank),
        "runs": str(args.runs),
        "selection": "All decoder seeds are independent repeats; no selection by validation/test results. Search settings frozen before evaluation.",
    }
    print(json.dumps(plan, ensure_ascii=False, indent=2), flush=True)
    if args.plan_only:
        return
    # Configuration and source hashes are sealed before any training or test data.
    protocol = {
        "plan": plan,
        "bank_config": bank_config,
        "vae_config": vae_config,
        "evaluation_configs": split_configs,
        "source_hashes": source_hashes(),
    }
    saved = args.runs / "protocol.json"
    if saved.exists() and json.loads(saved.read_text()) != protocol:
        raise ValueError(
            "Existing full run has a different protocol; use a new output directory"
        )
    args.runs.mkdir(parents=True, exist_ok=True)
    save_json(saved, protocol)
    if (args.runs / "COMPLETE.json").exists():
        print("Already complete", flush=True)
        return
    snapshot(args.runs / "source")
    save_json(
        args.runs / "design.json",
        {
            "config": bank_config,
            "family_definitions": definitions,
            "family_structure": structure,
        },
    )
    used = args.runs / "configs"
    save_json(used / "bank.json", bank_config)
    save_json(used / "vae.json", vae_config)
    for split, config in split_configs.items():
        save_json(used / f"{split}.json", config)
    started = time.monotonic()
    stages = []
    try:
        manifest_path = args.bank / "manifest.json"
        manifest = (
            json.loads(manifest_path.read_text())
            if manifest_path.exists()
            else None
        )
        if manifest is not None and (
            manifest["config"] != bank_config
            or manifest["counts_per_task"] != {"train": args.train_count}
            or manifest["implementation_sha256"] != source_hashes()
        ):
            raise ValueError("Source bank uses another collection protocol")
        if manifest is None or manifest["status"] != "complete":
            arguments = [
                "--bank",
                args.bank,
                "--config",
                used / "bank.json",
                "--source-only",
                "--train-count",
                args.train_count,
                "--devices",
                args.devices,
                "--models-per-gpu",
                packed,
                "--gpu-memory-gib",
                args.bank_memory_gib,
            ]
            if manifest is not None:
                arguments.append("--resume")
            stages.append(
                run_stage(
                    "bank",
                    "overlapping_groups.bank.collect",
                    arguments,
                    args.runs,
                )
            )
        audit_bank(args.bank, args.runs / "bank_novelty.json")
        common = [
            "--bank",
            args.bank,
            "--devices",
            args.devices,
            "--seeds",
            *args.seeds,
        ]
        stages.append(
            run_stage(
                "vae",
                "overlapping_groups.launch",
                [
                    "--phase",
                    "train",
                    *common,
                    "--config",
                    used / "vae.json",
                    "--runs",
                    args.runs / "vae",
                    "--gpu-memory-gib",
                    args.vae_memory_gib,
                ],
                args.runs,
            )
        )
        seal = {
            "configs": {
                split: sha256(used / f"{split}.json")
                for split in split_configs
            },
            "decoders": {
                str(seed): sha256(
                    args.runs / "vae" / f"wg_{seed}" / "decoder.pt"
                )
                for seed in args.seeds
            },
            "bank_sha256": sha256(args.bank / "manifest.json"),
        }
        seal_path = args.runs / "evaluation_seal.json"
        if seal_path.exists() and json.loads(seal_path.read_text()) != seal:
            raise ValueError("Evaluation settings or frozen decoders changed")
        save_json(seal_path, seal)
        for split in split_configs:
            stages.append(
                run_stage(
                    split,
                    "overlapping_groups.launch",
                    [
                        "--phase",
                        "evaluate",
                        *common,
                        "--config",
                        used / f"{split}.json",
                        "--vae-runs",
                        args.runs / "vae",
                        "--runs",
                        args.runs / split,
                        "--workers-per-device",
                        args.workers_per_device,
                        "--gpu-memory-gib",
                        args.search_memory_gib,
                    ],
                    args.runs,
                )
            )
        result = {
            "status": "complete",
            "elapsed_seconds": time.monotonic() - started,
            "stages": stages,
            "results": {
                split: json.loads(
                    (args.runs / split / "summary.json").read_text()
                )
                for split in split_configs
            },
        }
        save_json(args.runs / "COMPLETE.json", result)
        (args.runs / "FAILED.json").unlink(missing_ok=True)
        print(
            json.dumps(
                {
                    "status": "complete",
                    "elapsed_seconds": result["elapsed_seconds"],
                }
            ),
            flush=True,
        )
    except BaseException as error:
        save_json(
            args.runs / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
